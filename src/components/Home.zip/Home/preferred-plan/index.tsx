'use client'
import { useReducer, useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { getImgPath } from '@/utils/imagePath'


const TickIcon = () => (
  <svg
    width="20"
    height="20"
    viewBox="0 0 25 25"
    className="shrink-0"
    xmlns="http://www.w3.org/2000/svg"
  >
    <circle cx="12.5" cy="12.5" r="12.5" fill="#F3FAFF" />
    <path
      d="M17.7444 8.79787C17.4041 8.45708 16.8514 8.45729 16.5106 8.79787L10.9577 14.351L8.48961 11.883C8.14881 11.5422 7.59639 11.5422 7.2556 11.883C6.9148 12.2238 6.9148 12.7762 7.2556 13.117L10.3405 16.202C10.5108 16.3722 10.7341 16.4576 10.9574 16.4576C11.1807 16.4576 11.4042 16.3725 11.5745 16.202L17.7444 10.0319C18.0852 9.69131 18.0852 9.13865 17.7444 8.79787Z"
      fill="#2F73F2"
    />
  </svg>
);



const Preferred = () => {
  const [activeTab, setActiveTab] = useState('monthly')

  const initialTabConfig = {
    planType: 'monthly',
    basicPrice: 9999,
    professionalPrice: 14999,
    enterprisePrice:30000,
    duration: 'month',
  }
  interface State {
    planType: string
    basicPrice: number
    professionalPrice: number
    duration: string
  }
  interface Action {
    type: string
    payload: {
      duration: string
      basicPrice: number
      professionalPrice: number
    }
  }

  function reducer(tabConfig: State, action: Action) {
    switch (action.type) {
      case 'monthly':
        return {
          ...tabConfig,
          planType: action.type,
          basicPrice: action.payload.basicPrice,
          professionalPrice: action.payload.professionalPrice,
          duration: action.payload.duration,
        }
        break
      case 'annually':
        return {
          ...tabConfig,
          planType: action.type,
          basicPrice: action.payload.basicPrice,
          professionalPrice: action.payload.professionalPrice,
          duration: action.payload.duration,
        }
        break
      default:
        return tabConfig
    }
  }

  const [tabConfig, dispatch] = useReducer(reducer, initialTabConfig)

  const pathname = usePathname()
  console.log(pathname)

  return (
    <>
      <section
        className={`" dark:bg-darkmode " ${
          pathname === '/' ? 'py-20' : '-mt-52 pt-72'
        }`}>
        <div className='container'>
          <div data-aos='fade-up' data-aos-delay='200' data-aos-duration='1000'>
            <h2 className='text-secondary dark:text-white text-center'>
              Choose your website plan
            </h2>
            <p className='text-base font-normal text-SlateBlue dark:text-darktext max-w-585 text-center m-auto py-6'>
Pick a one‑time website package that fits your goals today, and upgrade later as your business grows.            </p>
          </div>
          <div>
           
            <div className='grid xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-2 grid-cols-1 gap-7'>
              <div
                data-aos='fade-up'
                data-aos-delay='200'
                data-aos-duration='1000'
                className='col-span-1 shadow-plan_shadwo rounded-2xl'>
                <div className='relative h-full'>
                  <div className='h-full bg-primary rounded-2xl overflow-hidden'>
                    <img
                      src={getImgPath('/images/price-plan/plan-image.png')}
                      alt=''
                      className='h-full'
                    />
                  </div>
                  <div className='pt-9 px-8 absolute z-3 top-0'>
                    <p className='text-white sm:text-3xl text-[22px] leading-[2rem] font-normal'>
                      Most founders start with
                      <span className='font-bold'> Growth Website package</span>
                    </p>
                    <p className='text-xl font-normal text-white pt-5'>
                     For serious businesses that want a high‑converting, SEO‑ready website from day one.
                    </p>
                  </div>
                </div>
              </div>
              <div
                data-aos='fade-up'
                data-aos-delay='400'
                data-aos-duration='1000'
                className='col-span-1 shadow-plan_shadwo rounded-2xl dark:bg-darklight'>
                <div className='flex grow flex-col p-6 sm:p-8'>
                  <span className='text-[22px] leading-[2rem] font-bold text-SlateBlue dark:text-darktext pb-3'>
                    Basic
                  </span>
                  <div>
                    <span className='text-5xl font-bold text-secondary dark:text-white'>
                      {`₹${tabConfig.basicPrice}`}
                      
                    </span>
                  </div>
                  <p className='text-SlateBlue dark:text-darktext opacity-75 text-base pt-6 border-b border-solid border-BorderLine dark:border-dark_border pb-5'>
                    Best for new businesses and personal brands.
                  </p>
                  <ul className='flex flex-col grow gap-5 pt-6'>
                    <li className='flex items-center gap-5'>
                      <TickIcon />

                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        4 page website
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />

                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        Basic SEO optimization
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />
                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        Live chat integration
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />
                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        5 Days support + 2 revisions
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />
                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        1 Year hosting + Domain + Free SSL(Free )
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />

                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        Single one time backup
                      </span>
                    </li>
                  </ul>
                  <Link
                    href='#'
                    className='btn mt-12 py-3 rounded-lg text-center'>
                    Get.Set.Go
                  </Link>
                </div>
              </div>
              <div
                data-aos='fade-up'
                data-aos-delay='400'
                data-aos-duration='1000'
                className='col-span-1 shadow-plan_shadwo rounded-2xl dark:bg-darklight'>
                <div className='flex grow flex-col p-6 sm:p-8'>
                  <span className='text-[22px] leading-[2rem] font-bold text-SlateBlue dark:text-darktext pb-3'>
                    Professional
                  </span>
                  <div>
                    <span className='text-5xl font-bold text-secondary dark:text-white'>
                      {`₹${tabConfig.professionalPrice}`}
                     
                    </span>
                  </div>
                  <p className='text-SlateBlue dark:text-darktext opacity-75 text-base pt-6 border-b border-solid border-BorderLine dark:border-dark_border pb-5'>
                    Best for service businesses that want more leads every month.
                  </p>
                  <ul className='flex flex-col grow gap-5 pt-6'>
                    <li className='flex items-center gap-5'>
                     <TickIcon />

                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        5-8 page website
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />

                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                       Advance SEO (10 keywords + On page SEO )
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />
                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        Whatsapp + Live chat
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />
                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        1 year hosting + Domain + Free SSL + 5 Business Emails
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />

                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        12 Days support + 4 revisions
                      </span>
                    </li>
                  </ul>
                  <Link
                    href='#'
                    className='btn mt-12 py-3 rounded-lg text-center'>
                    Get.Set.Go
                  </Link>
                </div>
              </div>
              <div
                data-aos='fade-up'
                data-aos-delay='600'
                data-aos-duration='1000'
                className='col-span-1 shadow-plan_shadwo rounded-2xl dark:bg-darklight'>
                <div className='flex grow flex-col p-6 sm:p-8'>
                  <span className='text-[22px] leading-[2rem] font-bold text-SlateBlue dark:text-darktext pb-3'>
                    Enterprise
                  </span>
                  <div>
                    <span className='text-5xl font-bold text-secondary dark:text-white'>
                      {`₹${tabConfig.enterprisePrice}`}
                     
                    </span>
                  </div>
                  <p className='text-SlateBlue dark:text-darktext opacity-75 text-base pt-6 border-b border-solid border-BorderLine dark:border-dark_border pb-5'>
                    Best for brands and stores selling products online
                  </p>
                  <ul className='flex flex-col grow gap-5 pt-6'>
                    <li className='flex items-center gap-5'>
                     <TickIcon />

                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        Product catalogue, cart, and checkout
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />

                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                       Online payments integration (GPay, PayTM, PhonePay, Credit / Debit cards)
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />
                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        Order management dashboard
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />
                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        Performance and basic security hardening
                      </span>
                    </li>
                    <li className='flex items-center gap-5'>
                     <TickIcon />

                      <span className='text-base text-SlateBlue dark:text-darktext font-normal'>
                        1 year hosting + Domain + Free SSL + 10 Business Emails
                      </span>
                    </li>
                  </ul>
                  <Link
                    href='#'
                    className='btn mt-12 py-3 rounded-lg text-center'>
                    Get.Set.Go
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Preferred
